# Email Configuration
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True

# Gmail credentials
EMAIL_HOST_USER = 'jovisicstefan73@gmail.com'  # Zamenite sa vašim Gmail-om
EMAIL_HOST_PASSWORD = 'jdbc uwhb xxek rpkg'  # App password iz Google naloga

# Lista admin email adresa
ADMIN_EMAILS = [
    'sudowhoami0@gmail.com',
]